package Main;

import Views.VueApplication;


public class Main {
	
	
	
		public static void main (String[] args)
		{
	VueApplication vAp;
	vAp = new VueApplication();
	vAp.setVisible (true);

		}
	
	}
