package Model;

import Model.General.Adress;

public class Bill {
	// Attributes
	private String label;
	private double price;
	private BonDeCmd bc;
	private Adress delivery_adr;
	
	// Constructors
	public Bill () {
		this("No label chosen",-1,new BonDeCmd(),new Adress());
	}
	
	public Bill(String _label, double _price, BonDeCmd _bc, Adress _adr) {
		label=_label;
		price=_price;
		bc=_bc;
		delivery_adr=_adr;
	}
	
	// Methods GET
	public String getLabel() {
		return label;
	}
	
	public double getPrice() {
		return price;
	}
	
	public BonDeCmd getCmd() {
		return bc;
	}
	
	public Adress getAdr() {
		return delivery_adr;
	}
}
