package Model;

import java.util.Vector;

import Model.General.Adress;

public class BonDeCmd {
	// Attributes
	private int idC;
	private Vector<Produits> V_Prods;
	private Adress adr;
	
	// Constructors
	public BonDeCmd () {
		this(-1,new Adress());
	}
	
	public BonDeCmd (int _idC, Adress _adr) {
		idC = _idC;
		adr = _adr;
		V_Prods = new Vector<Produits>();
	}
	
	// Methods GET
	public int getId() {
		return idC;
	}
	
	public Adress getAdr() {
		return adr;
	}
	
	public Vector<Produits> getProds() {
		return V_Prods;
	}
}
