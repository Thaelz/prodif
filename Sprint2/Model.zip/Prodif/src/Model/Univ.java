package Model;

import Model.General.Adress;

public class Univ {
	// Attributes
	private int idUniv;
	private Adress adr;
	
	// Constructors 
	
	public Univ() {
		this(-1, new Adress());
	}
	public Univ(int _id, Adress _adr) {
		idUniv=_id;
		adr=_adr;
	}
	
	// Methods GET
	public int getId() {
		return idUniv;
	}
	public Adress getAdr() {
		return adr;
	}
}
