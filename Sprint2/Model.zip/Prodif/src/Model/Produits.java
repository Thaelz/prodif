package Model;

public class Produits {
	private int idPro;
	private String label;
	private double price;
	
	// Constructors
	public Produits() {
		this(-1, "Undefined name", 0);
	}
	public Produits(int _id, String _label, double _price) {
		idPro = _id;
		label = _label;
		price = _price;
	}
	
	// Methods GET
	public int getId() {
		return idPro;
	}
	
	public String getLabel() {
		return label;
	}
	
	public double getPrice() {
		return price;
	}
}
