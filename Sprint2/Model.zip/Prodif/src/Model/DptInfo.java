package Model;

import Model.General.*;

public class DptInfo {
	private int idDpt;
	private Adress adr;
	private Univ univ;
	
	// Constructors
	public DptInfo() {
		this(0,new Adress(),new Univ());
	}
	public DptInfo(int _id, Adress _adr, Univ _univ) {
		idDpt = _id;
		adr=_adr;
		univ=_univ;
	}
	
	// Methods GET
	public int getId () {
		return idDpt;
	}
	
	public Adress getAdr() {
		return adr;
	}
	
	public Univ getUniv() {
		return univ;
	}
}
