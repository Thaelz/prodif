package Model.General;

public class Adress {
	private int nb;
	private String road;
	private String city;
	private int pcode;
	private String country;
	
	public Adress() {
		this(0, "Undefined road", "Undefined town", 00000, "Undefined country");
	}
	
	public Adress (int n, String r, String ci, int pc, String co) {
		nb = n;
		road = r;
		city = ci;
		pcode = pc;
		country = co;
	}
	
	public int getNb() {
		return this.nb;
	}
	
	public String getRoad () {
		return this.road;
	}
	
	public String getCity() {
		return this.city;
	}
	
	public int getPCode() {
		return this.pcode;
	}
	
	public String getCountry() {
		return this.country;
	}
	
}
